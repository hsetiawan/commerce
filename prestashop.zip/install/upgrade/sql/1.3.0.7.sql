SET NAMES 'utf8';

/* PHP:setAllGroupsOnHomeCategory(); */;
