SET NAMES 'utf8';

ALTER TABLE `PREFIX_carrier_lang` CHANGE `delay` `delay` VARCHAR(512) NULL;
